<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Beranda</title>
    <link rel="stylesheet" href="style.css">



    <style>

body {
    font-family: 'Arial', sans-serif;
    margin-top: 250px;
    background-color: gray;
    background: linear-gradient(to right, #ffcc00,#ff6600);
    padding: 0;
}
button {
            background-color: red; 
            color: #ffffff; 
            padding: 20px 15px;
            font-weight: bold;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

.container {
    width: 80%;
    margin: 0 auto;
    
}

header {
    background-color: #333;
    color: #fff;
    padding: 20px 0;
}

header h1 {
    margin: 0;
}

nav ul {
    list-style: none;
    margin: 0;
    padding: 0;
}

nav ul li {
    display: inline;
    margin-right: 20px;
    
}

nav ul li a{
    display: inline;
    margin-right: 20px;
    color: red;
}

nav a {
    text-decoration: none;
    color: #fff;
}

main {
    padding: 20px 0;
}

section {
    margin-bottom: 40px;
}

article img {
    width: 100%;
    height: auto;
}
.text{
    color: red;
}
    </style>
</head>

<body>


    <main class="container">
        <section id="featured">
            <center>
            <div class="article">
                <h1>Selamat Datang Di Galeri Poto</h1>
                <h3>Ayo Buat Setiap Momenmu Disini</h3>
                <nav>
                <ul>
                <center><a href="/login" type="button"><button type="submit"style="text-align: center;">login</button>
                 <a href="/register" type="button"><button type="submit"style="text-align: center;">Registrasi</button></center>
                    
                </ul>
            </div>

            

    </main>

</body>
</html>
