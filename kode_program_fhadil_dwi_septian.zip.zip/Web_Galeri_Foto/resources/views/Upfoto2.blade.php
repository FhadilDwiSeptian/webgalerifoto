<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="shortcut icon" href="image/logonavbar.jpeg" type="image/x-icon"> -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <title>Upload Foto-GaleriSoftengine</title>
    
    <style>
        body{
            background: url('{{ asset('img/bgGalery.png') }}');
            background-size: cover;
            background-position: center;
            background-blend-mode: multiply;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .row{
            margin-top: 1%;
            
        }

        .card-body{
            border-radius: 30px;
            
            /* background-image: url('img/bgGaleri.png'); */
        }

        .custom-input{
            border-radius: 20px;
        }

        .smaller-button{
            padding: 2px 5px;
            font-size: 14px;
        }

        .btn{
            border-radius: 80px;
        }
    </style>
</head>

<body>
    <!-- navbar -->
    @include('navbar')
    
    <section>
        <div class="container mt-5 pt-5">
            <div class="row justify-content-end">
                <div class="row">
                    <div class="col-12 col-md-5 mx-auto order-md-first">
                        <div class="card border-0 shadow">
                            <div class="card-body">

                            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-images" viewBox="0 0 16 16">
                                <path d="M4.502 9a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3"/>
                                <path d="M14.002 13a2 2 0 0 1-2 2h-10a2 2 0 0 1-2-2V5A2 2 0 0 1 2 3a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v8a2 2 0 0 1-1.998 2M14 2H4a1 1 0 0 0-1 1h9.002a2 2 0 0 1 2 2v7A1 1 0 0 0 15 11V3a1 1 0 0 0-1-1M2.002 4a1 1 0 0 0-1 1v8l2.646-2.354a.5.5 0 0 1 .63-.062l2.66 1.773 3.71-3.71a.5.5 0 0 1 .577-.094l1.777 1.947V5a1 1 0 0 0-1-1z"/>
                            </svg>

                            <form action="/foto" method="post" enctype="multipart/form-data">
                                @csrf
                                <input type="text" name="JudulFoto" placeholder="Judul Foto" class="form-control my-4 py-2 custom-input">
                                <input type="text" name="DeskripsiFoto" placeholder="DeskripsiFoto" class="form-control my-4 py-2 custom-input">
                                <input type="file" name="foto" placeholder="Lokasi File" class="form-control my-4 py-2 custom-input">

                                <select name="album" class="form-control my-4 py-2 custom-input">
                                    <option value="">Pilih Album</option>
                                    @foreach($album as $item)
                                        <option value="{{ $item->AlbumID }}">{{ $item->NamaAlbum }}</option>
                                    @endforeach
                                </select>
                                
                                <div class="text-center">
                                    <input type="submit" value="Upload" class="btn btn-primary">
                                </div>
                            </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
</html>

<!-- <select name="album" class="form-control my-4 py-2 custom-input">
                                    <option value="" selected disabled>Pilih Album</option>
                                        @foreach($album as $item)
                                            @if($item->UserID == Auth::id())
                                                <option value="{{ $item->AlbumID }}">{{ $item->NamaAlbum }}</option>
                                            @endif
                                        @endforeach
                                </select> -->