<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Photo</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <style>
       body {
            background-color: gray; /* b/ackground-color: white; Warna latar belakang */
            background: linear-gradient(to right, #ffcc00,#ff6600);
            font-weight: bold;
            font-family: Arial, sans-serif
            color: #ffffff; /* Warna teks */
        }
        form {
            max-width: 450px;
            margin: 50px auto;
            padding: 30px;
            font-weight: bold;
            color: white;
            background-color: black; /* Warna latar formulir */
            border-radius: 10px
        }
        label {
            display: block;
            font-weight: bold;
            margin-bottom: 8px;
        }
        input {
            width: 50%;
            padding: 10px;
            margin-bottom: 25px;
            box-sizing: border-box;
            border-radius:10px;
            border:none;
        }
        button {
            background-color: red; /* Warna tombol */
            color: black; /* Warna teks tombol */
            padding: 20px 15px;
            font-weight: bold;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .form-group {
            margin-bottom: 40px;
        }

        .form-group label {
            margin-bottom: 8px;
            justify-content: 10px;
            font-weight: bold;
            color: white; /* Warna teks putih */
        }

        .form-group input {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form-group button {
            padding: 10px;
            font-size: 16px;
            background-color: red; /* Warna tombol merah */
            color: #fff;
            font-weight: bold;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        tr td{
            justify-content:center;
            align-items: center;
        }
        /* Navbar */
.navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #333;
    padding: 25px 20px;
    background-color: white;
    color: white;
}

.nav-menu {
    list-style-type: none;
    display: flex;
    margin: 0;
    padding: 0;
}

.nav-item {
    margin-right: 20px;
  
}

.nav-link {
    text-decoration: none;
    color: black;
    font-weight: bold;
}

.logo {
    color: #fff;
    font-size: 1.5rem;
    text-decoration: none;
}

        
        </style>
    
    <header>
    <nav class="navbar">
        
        <ul class="nav-menu">
            <li class="nav-item"><a href="beranda" class="nav-link">Kembali</a></li>
        </ul>
    </nav>
</header>



    <div class="container">
        <form action="/tampilfoto" method="POST" enctype="multipart/form-data">
            @csrf
            <center> <h2>Tambahkan Fotomu</h2>
            <div class="form-group">
                <label for="photo_name">Nama Foto:</label>
                <input type="text" id="photo_name" name="judul" required>
            </div>
            <div class="form-group">
                <label for="photo_description">Deskripsi:</label>
                <textarea id="photo_description" name="deskripsi" required></textarea>
            </div>
            <div class="form-group">
                <label for="photo_file">Pilih Foto:</label>
                <input type="file" id="photo_file" name="gambar" accept="image/*" required>
            </div>
            <select name="album"  class="cl form-control form-control-lg inpucol">
                <option value="">Pilih Album</option>
                @foreach($album as $alb)
                     <option value="{{ $alb->AlbumID }}">{{$alb->NamaAlbum}}</option>
                @endforeach
            </select>
            <button type="submit">Tambah Foto</button></center>
        </form>
    </div>
</body>
</html>
