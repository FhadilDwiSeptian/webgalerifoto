<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">

    <title>Komeeeeenn</title>

    <style>
        body{
        background: url('{{ asset('img/bgGalery.png') }}');
        background-position: center;
        background-size: cover;
    }

    .grid{
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        margin: 40px;
        justify-content: center;
        align-items: center;
        grid-gap: 30px;
        /* margin-top: 2%; */
    }

    img{
        object-fit: cover;
    }

    .grid > article{
        /* box-shadow: 10px 5px 0px black; */
        border-radius: 35px;
        text-align: center;
        background: whitesmoke;
        width: 550px;
        transition: transform;
    }

    .grid > article img{
        border-top-left-radius: 30px;
        border-top-right-radius: 30px;
    }

    .konten{
        /* text-transform: uppercase; */
        /* cursor: progress; */
    }
    </style>
</head>
<body>
   
<div class="container">
<main class="grid">
<article>
    <img src="{{ Storage::url($foto->LokasiFile)}}" width="550" height="400">
    
    <!-- Menampilkan komentar di bawah foto -->
    @foreach($komen as $kmn)
        <p>{{$kmn->IsiKomentar}}</p>
    @endforeach

    <!-- Form untuk menambahkan komentar baru -->
    <form action="/berikomen/{{$foto->FotoID}}" method="post">
        @csrf
        <input type="text" name="isi" placeholder="Tulis Komentar" class="form-control my-4 py-2 custom-input">
        <button type="submit" class="form-control my-4 py-2 custom-input">Kirim</button>
    </form>
</article>
</main>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>

</body>
</html>