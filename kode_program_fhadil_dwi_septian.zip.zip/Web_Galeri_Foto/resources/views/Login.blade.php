<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: gray; /* Warna latar belakang putih */
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            background-size: cover;
            background: linear-gradient(to right, #ffcc00,#ff6600);
            
        }

        .login-container {
            background-color: black;
            padding: 20px;
            font-weight: bold;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .login-container h2 {
            text-align: center;
            color: white; /* Warna teks putih*/
        }
        input {
            width: 70%;
            padding: 6px;
            margin-bottom: 25px;
            box-sizing: border-box;
            border-radius:10px;
        }

        .login-form {
            display: flex;
            flex-direction: column;
            color: white;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            margin-bottom: 8px;
            font-weight: bold;
            color: white; /* Warna teks putih*/
        }

        .form-group input {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .form-group button {
            padding: 10px;
            font-size: 16px;
            background-color: red; /* Warna tombol hijau */
            color: #fff;
            font-weight: bold;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        h1{
            color: white;
        }
    </style>
</head>
<body>

<div class="login-container">
  <center><h1>Form Login</h1> 

    {{session()->get('pesan')}}
  </center>
    <form class="login-form" action="/aksilogin" method="post">
        @csrf
        <div class="form-group">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
        </div>

        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
        </div>
        <div class="form-group">
            <tr>
            <!-- <td colspan="2" class="mid-text">Sudah punya akun? <a herf="/login">masuk sekarang</a></td> -->
    </div>

        <div class="form-group">
            <tr>
            <center><button type="submit">Login</button></center>
        </div>
    </form>
</div>

</body>
</html>
