<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <title>Lihat Foto</title>
    <header>
    <nav>
    <a href="{{ url('/beranda')}}" class="logout-button">kembali</a>
    </nav>
  </header>
    <style>
    body{
        background: url('{{ asset('img/bgGalery.png') }}');
        background-position: center;
        background-size: cover;
        background: linear-gradient(to right, #ffcc00,#ff6600);
    }

    .nav {
    background-color: white;
    color: black;
    text-align: center;
    padding: 20px 0;
}

.nav h1 {
    margin: 0;
}

nav {
    background-color:  #ff6600;
    color: white;
    text-align: center;
    padding: 10px 0;
}

nav a {
    float: left;
    display: block;
    color: black;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

nav a:hover {
    background-color: #ddd;
    color: black;
}

    .grid{
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        margin: 40px;
        justify-content: center;
        align-items: center;
        grid-gap: 30px;
        /* margin-top: 2%; */
    }

    img{
        object-fit: cover;
    }

    .grid > article{
        box-shadow: 10px 5px 0px black;
        border-radius: 35px;
        text-align: center;
        background: whitesmoke;
        width: 265px;
        transition: transform;
    }

    .grid > article img{
        border-top-left-radius: 30px;
        border-top-right-radius: 30px;
    }

    .konten{
        /* text-transform: uppercase; */
        /* cursor: progress; */
    }

    /* .grid > article:hover{
        transform: scale(1.1);
    } */

    @media (max-width: 1000px) {
        .grid{
            grid-template-columns: repeat(2, 1fr);
        }
    }
    @media (max-width: 800px) {
        .grid{
            grid-template-columns: repeat(1, 1fr);
        }
    }
    </style>
</head>

<body>
    <!-- navbar -->

    <br><br>

    
    <div class="container">
        <main class="grid">
            @foreach($foto as $fotos)
                <article>       
                    <img src="{{ Storage::url($fotos->LokasiFile) }}" width="265" height="265">
                    <div class="konten">
                        <p>Username : {{$fotos->UserID}} </p>
                        <p class="text-dark">Judul Foto: {{$fotos->JudulFoto}} </p>
                        <p>Deskripsi : {{$fotos->DeskripsiFoto}} </p>

                        <a href="/likee">
                        <i class="fa-solid fa-heart" style="font-size: 25px;" ></i>
                        </a>

                        <!-- <a href="/likee">
                        <i class="fa-regular fa-heart" style="font-size: 25px;" ></i>
                        </a> -->

                        <a href="/komene">
                        <i class="fa-regular fa-message" style="font-size: 20px"></i> 
                        </a>
                         
                    </div>
                </article>
                @endforeach
        </main>
    </div>
    <script src="https://kit.fontawesome.com/29c53c391a.js" crossorigin="anonymous"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
</html>