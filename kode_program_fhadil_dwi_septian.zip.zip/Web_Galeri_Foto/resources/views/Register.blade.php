<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <style>
        body {
            background-color: gray; /* b/ackground-color: white; Warna latar belakang */
            background: linear-gradient(to right, #ffcc00,#ff6600);
            font-weight: bold;
            font-family: Arial, sans-serif;
            justify-content:center;
            height: 100vh;
            align-items: center;
            color: #ffffff; /* Warna teks */
        }
        form {
            max-width: 450px;
            margin: 50px auto;
            padding: 30px;
            font-weight: bold;
            background-color: black; /* Warna latar formulir */
            border-radius: 10px
        }
        label {
            display: block;
            font-weight: bold;
            margin-bottom: 8px;
        }
        input {
            width: 50%;
            padding: 10px;
            margin-bottom: 25px;
            box-sizing: border-box;
            border-radius:10px;
            border:none;
        }
        button {
            background-color: red; /* Warna tombol */
            color: #ffffff; /* Warna teks tombol */
            padding: 20px 15px;
            font-weight: bold;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .form-group {
            margin-bottom: 40px;
        }

        .form-group label {
            margin-bottom: 8px;
            justify-content: 10px;
            font-weight: bold;
            color: white; /* Warna teks putih */
        }

        .form-group input {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form-group button {
            padding: 10px;
            font-size: 16px;
            background-color: red; /* Warna tombol merah */
            color: #fff;
            font-weight: bold;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        tr td{
            justify-content:center;
            align-items: center;
        }

    </style>
</head>
<body>
    

    <form action="/register" method="post">
        @csrf
    <center><a type="submit"style="text-align: center;"><h1>Register</h1></a></center>
    <br>
    <table>
    <div class="form-group">
    <tr>
        <td><label for="username" >Username</lable></td>
        <td>:</td>
        <td><input type="username" id="username" name="username" style="width:270px;" required></td>
    </tr>
    <tr>
       <td> <label for="password">Password</lable></td>
       <td>:</td>
       <td><input type="password" id="password" name="password" style="width:270px;" required></td>
    </tr>
    <tr>
        <td><label for="email">Email</lable></td>
        <td>:</td>
        <td><input type="email" id="email" name="email" style="width:270px;" required></td>
    </tr>
        <tr>
       <td> <label for="nama lengkap">Nama Lengkap</lable></td>
        <td>:</td>
        <td><input type="text" id="nama lengkap" name="namalengkap" style="width:270px;" required></td>
    </tr>
    <tr>
       <td> <label for="alaamat">Alamat</lable></td>
       <td>:</td>
       <td><input type="alamat" id="alaamat" name="alamat" style="width:270px;" required></td>
    </tr>
</table>
    
        <center><button type="submit"style="text-align: center;">Sign Up </button></center>
      
        </div>
    </form>

</body>
</html>