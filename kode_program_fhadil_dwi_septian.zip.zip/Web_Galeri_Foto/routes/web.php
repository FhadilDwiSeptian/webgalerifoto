<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\GaleriController;
use App\Models\User;
use App\Models\Foto;
use App\Models\Album;
use App\Models\Like;
use App\Models\Komen;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/home', function () {
    return view('Home');
});
Route::get('/login', function () {
    return view('Login');
});
Route::get('/register', function () {
    return view('Register');
});

Route::post('/register', [GaleriController::class,'aksiregister']);



Route::get('/buatalbum', function () {
    return view('album3');
});
Route::get('/album3', function () {
    return view('Lihatalbum');
});




// Route::get('/tambahalbum', function () {
//     return view('Tambahalbum');
// });

//album dan tamah album

// Route::get('/lihatablum', function () {
//     return view('Lihatalbum');
// });
// Route::post('/Buatalbum', [GaleriController::class,'album']);


// Route::get('/buatalbum', function () {
//     return view('Lihatalbum');
// });
// Route::post('/buatalbum', [GaleriController::class,'alsiAlbum']);

// Route::get('/lihatalbum', [GaleriController::class,'tampilAlbum']);



//foto

Route::get('/tambahfoto', function () {
    return view('Tambahfoto');
});
Route::get('/tambahfoto', [GaleriController::class,'unggahfoto']);

Route::post('/tampilfoto', [GaleriController::class,'unggahfotoAksi']);

Route::get('/tampilfoto/{AlbumID}', [GaleriController::class,'tampilFoto']);

//home
Route::get('/beranda', [GaleriController::class,'homeFoto']);

Route::post('/aksilogin', [GaleriController::class,'aksilogin']);

Route::get('/likee/{FotoID}', [GaleriController::class, 'suka']);

//komentar
Route::get('/komene/{FotoID}', [GaleriController::class, 'komen']);
Route::post('/berikomen/{FotoID}', [GaleriController::class, 'komene']);


 Route::get('/lihatalbum', [GaleriController::class, 'tampilAlbum']);



Route::get('/lihatalbum', function () {
$album = Album::where('UserID',session('user')->UserID)->get();
    return view('lihatalbum',compact('album'));
});
Route::get('/buatAlbum', function () {
    return view('album3');
});
Route::get('/album3', [GaleriController::class, 'album']);
Route::post('/album3', [GaleriController::class, 'aksialbum']);
Route::get('/tampilfoto', [GaleriController::class, 'tampilAlbum']);


// Route::get('/lihatfoto/{AlbumID}', [GaleriController::class, 'tampilFoto']);


// Route::get('/beranda', function () {
//     return view('Beranda');
// });


// Route::get('/home2', function () {
//     return view('Home2');
// });


Route::post('/album3', [GaleriController::class, 'aksialbum']);
Route::post('/lihatalbum', [GaleriController::class, 'aksialbum']);




// Route::post('/Register',[GaleriController::class,'aksiregister']);
// Route::post('/login',[GaleriController::class,'aksilogin']);
// Route::post('/album',[GaleriController::class,'aksialbum']);

// Route::get('/tambahfoto',[GaleriController::class,'unggahfoto']);
// Route::post('/tambahfoto',[GaleriController::class,'unggahfotoAksi']);

