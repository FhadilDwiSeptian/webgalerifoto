<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Foto;
use App\Models\Album;
use App\Models\LikeFoto;
use App\Models\KomentarFoto;
use Carbon\carbon;


class GaleriController extends Controller
{
    public function panggilview(){
        return view('Register');
    }
    public function aksiregister (Request $request){

    $data = new User();
    $data->Username =$request->input('username'); 
    $data->Password =$request->input('password');
    $data->Email =$request->input('email');
    $data->NamaLengkap=$request->input('namalengkap'); 
    $data->Alamat =$request->input('alamat');
     $data->save(); 
    // dd ($data);
     return redirect('/login'); 
    }

public function aksilogin (Request $request)
{
    $data = User::where('username', $request->input('username'))->where('password', $request->input('password'))->first();
    if($data != null){
        session()->put('user', $data);
        return redirect ('/beranda');
    }else{
        return redirect()->back()->with('pesan','username/Password salah!!');
        // dd($data);
    }
    }
    
    

    //album
    public function album() {
        if (session('user') ==! null) {
            return view('/album3');
        } else{
            return redirect('/lihatalbum');
        }
    }

    public function aksialbum(Request $req)
    {
        
    $data = new Album(); 
    $data->NamaAlbum = $req->input('NamaAlbum');
    $data->Deskripsi = $req->input('Deskripsi');
    $data->TanggalDibuat = date ('Y-m-d');
    $data->UserID = session('user')->UserID;
    $data->save();

    return redirect('/lihatalbum');
}

public function tampilAlbum(){
    if(session('user') != null) {
        $album = Album::where('UserID', session('user')->UserID)->get();
        return view('Album3', compact('album'));
        // dd($album);
    } else {
        return redirect('/login');
    }
}


//unggah foto
public function unggahfoto(){   
    $album = Album::where('UserID', session('user')->UserID)->get();
    return view('Tambahfoto', compact('album'));
}


public function unggahfotoAksi(Request $request){

    if($request->hasFile('gambar')){

        $lokasi = $request->file('gambar')->store('public/images');
        $data = new Foto;
        $data->JudulFoto = $request->input('judul');
        $data->DeskripsiFoto = $request->input('deskripsi');
        $data->TanggalUnggah = now();
        $data->LokasiFile =  $lokasi;
        $data->AlbumID = $request->input('album');
        $data->UserID = session('user')->UserID;

        $data->save();
        return redirect('/beranda');
        


    }else{
        return redirect()->back()->with('err','Foto gagal diunggah');
    }

}

public function tampilFoto($AlbumID){
    if(session('user') != null) {
        $like = LikeFoto::all();
        $komen = Komentarfoto::all();
        $foto = Foto::where('AlbumID', $AlbumID)->get();
        return view('lihatfoto', compact('foto','komen','like'));
        // dd($album);
    } else {
        return redirect('/login');
}

}

//tampillan di Home
public function homeFoto() {
    $foto = Foto::all();
    $user = User::all();
    $like = LikeFoto::all();
    $komen = Komentarfoto::all();
    return view('home2',compact('foto','user','like','komen'));//menyesuaikan variabel
}

public function suka($FotoID) {
    $cek = LikeFoto::where('UserID', session('user')->UserID)->where('FotoID', $FotoID)->first(); 

    if ($cek==null) {
    //kalo data nya kosong dia memberi like, kalo datanya sudah adda berarti dia hapus like itu
    $data = new LikeFoto;
    $data->FotoID = $FotoID; //diambil dari parameter
    $data->UserID = session('user')->UserID; 
    $data->TanggalLike = Carbon::now();
    $data->save();
    return redirect()->back();
    
    } else {
        $cek->delete();
        return redirect()->back();
        // dd($cek);
    }       
}

//komeeen
// public function komen(Request $request, $FotoID) {


    public function komen(Request $request, $FotoID) {


        $foto = Foto::find($FotoID);
        // $user = User:: all();
        $komen = Komentarfoto::where('FotoID', $FotoID)->get();
        return view('Komen2', compact('foto', 'komen'));
    }
    public function komene(Request $request, $FotoID){
        $data = new Komentarfoto;
        $data->FotoID = $FotoID;
        $data->UserID = session('user')->UserID;
        $data->IsiKomentar = $request->input('isi');
        $data->TanggalKomentar = Carbon::now();

        // dd($data);
        $data->save();
        return redirect()->back();
    }

    

//     $foto = Foto::find($FotoID);
//     // $user = User:: all();
//     $komen = Komen::where('FotoID', $FotoID)->get();
//     return view('komene', compact('foto', 'komen'));
// }
// public function komene(Request $request, $FotoID){
//     $data = new Komen;
//     $data->FotoID = $FotoID;
//     $data->UserID = session('user')->UserID;
//     $data->IsiKomentar = $request->input('isi');
//     $data->TanggalKomentar = Carbon::now();

//     // dd($data);
//     $data->save();
//     return redirect()->back();
// }

}