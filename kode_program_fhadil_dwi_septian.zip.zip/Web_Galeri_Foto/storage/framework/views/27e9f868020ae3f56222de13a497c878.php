<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <title>Home-Galeri</title>

    <style>
    body{
        background: url('<?php echo e(asset('img/bgGalery.png')); ?>');
        background-position: center;
        background-size: cover;
        background: linear-gradient(to right, #ffcc00,#ff6600);
            
    }

    .grid{
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        margin: 40px;
        grid-gap: 30px;
    }

    img{
        object-fit: cover;
    }

    .grid > article{
        box-shadow: 10px 5px 0px black;
        border-radius: 35px;
        text-align: center;
        background: whitesmoke;
        width: 265px;
        transition: transform;
    }

    .grid > article img{
        border-top-left-radius: 30px;
        border-top-right-radius: 30px;
    }

    .konten{
        /* text-transform: uppercase; */
        /* cursor: progress; */
    }

    @media (max-width: 1000px) {
        .grid{
            grid-template-columns: repeat(2, 1fr);
        }
    }
    @media (max-width: 800px) {
        .grid{
            grid-template-columns: repeat(1, 1fr);
        }
    }

    
    </style>
</head>

<body>
    <!-- navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Galeri</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="tambahfoto">Tambah Foto</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="lihatalbum">Lihat Album</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="home">Log out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <br><br>

   
    <div class="container">
        <main class="grid">
           <?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fotos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article>       
                    <img src="<?php echo e(Storage::url($fotos->LokasiFile)); ?>" width="265" height="265">
                    <div class="konten">
                        <p>Username : <?php if($nama = $user-> where('UserID',$fotos->UserID)->first()): ?>
                            <?php echo e($nama->Username); ?>

                            <?php endif; ?>
                        </p>
                        <p class="text-dark">Judul Foto: <?php echo e($fotos->JudulFoto); ?></p>
                        <p>Deskripsi :  <?php echo e($fotos->DeskripsiFoto); ?></p>

                        <?php if($cek = $like->where('UserID', session('user')->UserID)->where('FotoID', $fotos->FotoID)->first()): ?>
                        <a href="/likee/<?php echo e($fotos->FotoID); ?>">
                        <i class="fa-solid fa-heart" style="font-size: 25px;" ></i>
                        </a>
                        <?php echo e($like->where('FotoID', $fotos->FotoID)->count()); ?>


                        <?php else: ?>
                        <a href="/likee/<?php echo e($fotos->FotoID); ?>">
                        <i class="fa-regular fa-heart" style="font-size: 25px;" ></i>
                        </a>
                        <?php echo e($like->where('FotoID', $fotos->FotoID)->count()); ?>

                        <?php endif; ?>

                        <a href="/komene/<?php echo e($fotos->FotoID); ?>">
                        <i class="fa-regular fa-message" style="font-size: 20px"></i> 
                        </a>
                        <?php echo e($komen->where('FotoID', $fotos->FotoID)->count()); ?>

                         
                    </div>
                </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </main>
    </div>
    
    <script src="https://kit.fontawesome.com/29c53c391a.js" crossorigin="anonymous"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH C:\Users\Lenovo\Web_Galeri_Foto\resources\views/home2.blade.php ENDPATH**/ ?>