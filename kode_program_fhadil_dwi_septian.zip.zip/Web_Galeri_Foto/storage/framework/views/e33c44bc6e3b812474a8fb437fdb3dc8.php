<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <title>Home-GaleriSoftengine</title>

    <style>
    body{
        background: url('<?php echo e(asset('img/bgGalery.png')); ?>');
        background-position: center;
        background-size: cover;
    }

    .grid{
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        margin: 40px;
        justify-content: center;
        align-items: center;
        grid-gap: 30px;
        /* margin-top: 2%; */
    }

    img{
        object-fit: cover;
    }

    .grid > article{
        box-shadow: 10px 5px 0px black;
        border-radius: 35px;
        text-align: center;
        background: whitesmoke;
        width: 265px;
        transition: transform;
    }

    .grid > article img{
        border-top-left-radius: 30px;
        border-top-right-radius: 30px;
    }

    .konten{
        /* text-transform: uppercase; */
        /* cursor: progress; */
    }

    /* .grid > article:hover{
        transform: scale(1.1);
    } */

    @media (max-width: 1000px) {
        .grid{
            grid-template-columns: repeat(2, 1fr);
        }
    }
    @media (max-width: 800px) {
        .grid{
            grid-template-columns: repeat(1, 1fr);
        }
    }
    </style>
</head>

<body>
    <!-- navbar -->
    <br><br>

   
    <div class="container">
        <main class="grid">
           <?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fotos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article>       
                    <img src="<?php echo e(Storage::url($fotos->LokasiFile)); ?>" width="265" height="265">
                    <div class="konten">
                        <p>Username : <?php echo e($fotos->Username); ?></p>
                        <p class="text-dark">Judul Foto: <?php echo e($fotos->JudulFoto); ?></p>
                        <p>Deskripsi :  <?php echo e($fotos->DeskripsiFoto); ?></p>

                        <?php if($cek = $like->where('UserID', session('user')->UserID)->where('FotoID', $fotos->FotoID)->first()): ?>
                        <a href="/likee/<?php echo e($fotos->FotoID); ?>">
                        <i class="fa-solid fa-heart" style="font-size: 25px;" ></i>
                        </a>
                        <?php echo e($like->where('FotoID', $fotos->FotoID)->count()); ?>


                        <?php else: ?>
                        <a href="/likee/<?php echo e($fotos->FotoID); ?>">
                        <i class="fa-regular fa-heart" style="font-size: 25px;" ></i>
                        </a>
                        <?php echo e($like->where('FotoID', $fotos->FotoID)->count()); ?>

                        <?php endif; ?>

                        <a href="/komene/<?php echo e($fotos->FotoID); ?>">
                        <i class="fa-regular fa-message" style="font-size: 20px"></i> 
                        </a>
                        <?php echo e($komen->where('FotoID', $fotos->FotoID)->count()); ?>

                         
                    </div>
                </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </main>
    </div>
    <div class="container">
        <main class="grid">
    <?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fotos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <article>
    <img src="<?php echo e(Storage::url($fotos->LokasiFile)); ?>" width="265" height="265">
        <div class="konten">
        <h6>Login untuk melihat, Like & Komen foto</h4>
        <p>Username : <?php echo e($fotos->UserID); ?></p>
        <p class="text-dark">Judul Foto: <?php echo e($fotos->JudulFoto); ?></p>
        <p>Deskripsi :  <?php echo e($fotos->DeskripsiFoto); ?></p>
    </div>
    </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </main>
    </div>

    <script src="https://kit.fontawesome.com/29c53c391a.js" crossorigin="anonymous"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
</html>

    <?php /**PATH C:\Users\Lenovo\Web_Galeri_Foto\resources\views/Home2.blade.php ENDPATH**/ ?>