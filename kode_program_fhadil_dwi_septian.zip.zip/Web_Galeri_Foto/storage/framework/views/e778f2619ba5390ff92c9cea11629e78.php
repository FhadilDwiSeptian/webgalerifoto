<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lihat Album</title>
    <link rel="stylesheet" href="styles.css">
    <!-- Font Awesome untuk ikon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha384-HEKzy7BcXr3+S3PIkE0ah7h0E+1K/O4clHA3FK9v9eisnqEkF2nI4lUOwH2fm7Wy" crossorigin="anonymous">
</head>
<body>
<header>
    <nav>
    <a href="beranda" class="logout-button">kembali</a>
    </nav>
  </header>
  <form action="/album3" method="POST">
        <?php echo csrf_field(); ?>

    <div class="nav">
        <center><h1>Lihat Album</h1></center>
    </div>


    <style>
body {
    font-family: Arial, sans-serif;
    margin: 0;
    background: linear-gradient(to right, #ffcc00,#ff6600);
    padding: 0;
}

form button {
    color: black;
}

.container {
    width: 80%;
    margin: 0 auto;
}

.nav {
    background-color: white;
    color: black;
    text-align: center;
    padding: 20px 0;
}

.nav h1 {
    margin: 0;
}

nav {
    background-color:  #ff6600;
    color: white;
    text-align: center;
    padding: 10px 0;
}

nav a {
    float: left;
    display: block;
    color: black;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

nav a:hover {
    background-color: #ddd;
    color: black;
}

.container {
    width: 80%;
    margin: 0 auto;
}

#album-list {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    margin-top: 20px;
}

.album {
    background-color: #f2f2f2;
    border-radius: 5px;
    padding: 20px;
    margin: 10px;
    text-align: center;
}

.album h2 {
    margin-top: 0;
}

.album a {
    display: block;
    text-decoration: none;
    color:  #ff6600;
    margin-top: 10px;
}

.album a:hover {
    text-decoration: underline;
}
</style>

    <main class="container">
        <section id="album-list">
            <?php $__currentLoopData = $album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="album">
                <h2><?php echo e($item->JudulAlbum); ?></h2>
                <p><?php echo e($item->Deskripsi); ?></p>
                <a href="/tampilfoto/ <?php echo e($item->AlbumID); ?> "><i class="fas fa-images"></i> Lihat Foto</a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>
    </main>

    <footer>
        <div class="container">
            
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <div class="form-group">
    </div>

<center>  <a href="album3"><input type="submit" value="Buat Album Baru" class="btn btn-primary" style="border-radius: 100px;"></a></center>
  <style>
            <tr>
           
        </div>
</body>
</html>
<?php /**PATH C:\Users\Lenovo\Web_Galeri_Foto\resources\views/Lihatalbum.blade.php ENDPATH**/ ?>