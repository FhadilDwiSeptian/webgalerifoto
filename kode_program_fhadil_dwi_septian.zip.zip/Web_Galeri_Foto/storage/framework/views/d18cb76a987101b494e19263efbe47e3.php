<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Photo</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<header>
    <nav>
    <a href="beranda" class="logout-button">kembali</a>
    </nav>
  </header>
    <style>
       body {
            background-color: gray; /* b/ackground-color: white; Warna latar belakang */
            background: linear-gradient(to right, #ffcc00,#ff6600);
            font-weight: bold;
            font-family: Arial, sans-serif
            color: #ffffff; /* Warna teks */
        }
        form {
            max-width: 450px;
            margin: 50px auto;
            padding: 30px;
            font-weight: bold;
            background-color: transparent; /* Warna latar formulir */
            border-radius: 10px
        }
        label {
            display: block;
            font-weight: bold;
            margin-bottom: 8px;
        }
        input {
            width: 50%;
            padding: 10px;
            margin-bottom: 25px;
            box-sizing: border-box;
            border-radius:10px;
            border:none;
        }
        button {
            background-color: red; /* Warna tombol */
            color: #ffffff; /* Warna teks tombol */
            padding: 20px 15px;
            font-weight: bold;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .form-group {
            margin-bottom: 40px;
        }

        .form-group label {
            margin-bottom: 8px;
            justify-content: 10px;
            font-weight: bold;
            color: black; /* Warna teks putih */
        }

        .form-group input {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form-group button {
            padding: 10px;
            font-size: 16px;
            background-color: red; /* Warna tombol merah */
            color: #fff;
            font-weight: bold;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        tr td{
            justify-content:center;
            align-items: center;
        }
        
        </style>
    

    <div class="container">
       <center> <h2>Tambahkan Fotomu</h2>
        <form action="/tambahfoto" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="photo_name">Nama Foto:</label>
                <input type="text" id="photo_name" name="judul" required>
            </div>
            <div class="form-group">
                <label for="photo_description">Deskripsi:</label>
                <textarea id="photo_description" name="deskripsi" required></textarea>
            </div>
            <div class="form-group">
                <label for="photo_file">Pilih Foto:</label>
                <input type="file" id="photo_file" name="gambar" accept="image/*" required>
            </div>
            <select name="album"  class="cl form-control form-control-lg inpucol">
                <?php $__currentLoopData = $album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($alb->AlbumID); ?>"><?php echo e($alb->NamaAlbum); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button type="submit">Tambah Foto</button></center>
        </form>
    </div>
</body>
</html>
<?php /**PATH C:\Users\Lenovo\Web_Galeri_Foto\resources\views/tambahfoto.blade.php ENDPATH**/ ?>