<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <title>Home-GaleriSoftengine</title>

    <style>
    body{
        background: url('<?php echo e(asset('img/bgGalery.png')); ?>');
        background-position: center;
        background-size: cover;
    }

    .grid{
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        margin: 40px;
        justify-content: center;
        align-items: center;
        grid-gap: 30px;
        /* margin-top: 2%; */
    }

    img{
        object-fit: cover;
    }

    .grid > article{
        box-shadow: 10px 5px 0px black;
        border-radius: 35px;
        text-align: center;
        background: whitesmoke;
        width: 265px;
        transition: transform;
    }

    .grid > article img{
        border-top-left-radius: 30px;
        border-top-right-radius: 30px;
    }

    .konten{
        /* text-transform: uppercase; */
        /* cursor: progress; */
    }

    /* .grid > article:hover{
        transform: scale(1.1);
    } */

    @media (max-width: 1000px) {
        .grid{
            grid-template-columns: repeat(2, 1fr);
        }
    }
    @media (max-width: 800px) {
        .grid{
            grid-template-columns: repeat(1, 1fr);
        }
    }
    </style>
</head>

<body>
    <!-- navbar -->
    <nav>
        <a href="album">Buat Album</a>
        <a href="tambahfoto">Tambah Foto</a>
        <a href="lihatalbum">Lihat Album</a>
</nav>
    <br><br>

    
    <div class="container">
        <main class="grid">
           
                <article>       
                    <img src="<?php echo e(Storage::url($fotos->LokasiFile)); ?>" width="265" height="265">
                    <div class="konten">
                        <p>Username :  </p>
                        <p class="text-dark">Judul Foto:  </p>
                        <p>Deskripsi : </p>

                        <a href="/likee">
                        <i class="fa-solid fa-heart" style="font-size: 25px;" ></i>
                        </a>

                        <!-- <a href="/likee">
                        <i class="fa-regular fa-heart" style="font-size: 25px;" ></i>
                        </a> -->

                        <a href="/komene">
                        <i class="fa-regular fa-message" style="font-size: 20px"></i> 
                        </a>
                         
                    </div>
                </article>
                
        </main>
    </div>
    <script src="https://kit.fontawesome.com/29c53c391a.js" crossorigin="anonymous"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\Users\Lenovo\Web_Galeri_Foto\resources\views/Beranda.blade.php ENDPATH**/ ?>