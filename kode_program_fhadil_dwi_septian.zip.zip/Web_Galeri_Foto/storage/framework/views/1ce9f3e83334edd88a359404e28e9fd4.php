<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Album</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <h1 class="logo">Photo Gallery</h1>
            <ul class="nav-links">
                <li><a href="#">Home</a></li>
                <li><a href="#">Gallery</a></li>
                <li><a href="#">About</a></li>
                <li><a href="#">Contact</a></li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <h2>Add New Album</h2>
        <form action="/album" method="POST">
            <div class="form-group">
                <label for="album_name">Album Name:</label>
                <input type="text" id="album_name" name="NamaAlbum" required>
            </div>
            <div class="form-group">
                <label for="album_description">Description:</label>
                <textarea id="album_description" name="Deskripsi" required></textarea>
            </div>
            <button type="submit">Add Album</button>
        </form>
    </div>
</body>
</html>
<?php /**PATH C:\Users\Lenovo\Web_Galeri_Foto\resources\views/Tambahalbum.blade.php ENDPATH**/ ?>