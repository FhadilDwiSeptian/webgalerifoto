<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body><header>
    <nav>
    <a href="beranda" class="logout-button">kembali</a>
    </nav>
  </header>
  <form action="/album" method="POST">
        <?php echo csrf_field(); ?>

    


    <div class="contain-log">
      <center>  <div class="text-top">Buat Album</div>
        <table cellspacing="5">
            <form action="/buatalbumAksi" method="post">
                <?php echo csrf_field(); ?>
                <tr>
                    <td>Nama Album :</td>
                </tr>
                <tr>
                    <td><input type="text" name="namaalb" placeholder="Masukkan judul album" class="jdl-alb"></td>
                </tr>
                <tr>
                    <td>Deskripsi :</td>
                </tr>
                <tr>
                    <td>
                        <textarea name="deskripsi" class="desk-alb">Masukkan deskripsi album</textarea>
                    </td>
                </tr>
                <tr>
                    <td><center><button class="buat">Buat</button></center></td></center>
                    <a class="nav-link" href="lihatalbum">Buat</a>
                </tr>
            </form>
        </table>
    </div>

    </body>
</html><?php /**PATH C:\Users\Lenovo\Web_Galeri_Foto\resources\views/Buatalbum.blade.php ENDPATH**/ ?>