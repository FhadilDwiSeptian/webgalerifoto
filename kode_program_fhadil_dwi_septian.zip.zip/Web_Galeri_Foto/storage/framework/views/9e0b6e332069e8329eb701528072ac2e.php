<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <title>Album</title>

    <style>
    body{
        background: url('img/bgGalery.png');
        background-position: center;
        background-size: cover;
    }

    .grid{
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        margin: 40px;
        justify-content: center;
        align-items: center;
        grid-gap: 30px;
        /* margin-top: 2%; */
    }

    img{
        object-fit: cover;
    }

    .grid > article{
        box-shadow: 10px 5px 0px black;
        border-radius: 35px;
        text-align: center;
        background: whitesmoke;
        width: 265px;
        transition: transform;
    }

    .grid > article img{
        border-top-left-radius: 30px;
        border-top-right-radius: 30px;
    }

    .konten{
        /* text-transform: uppercase; */
        /* cursor: progress; */
    }

    .grid > article:hover{
        transform: scale(1.1);
    }

    @media (max-width: 1000px) {
        .grid{
            grid-template-columns: repeat(2, 1fr);
        }
    }
    @media (max-width: 800px) {
        .grid{
            grid-template-columns: repeat(1, 1fr);
        }
    }
    </style>
</head>

<body>
    <!-- navbar -->
  
    <br><br>
    <div class="text-center">   
        <a href="/buatAlbum">
        <input type="submit" value="Buat Album Baru" class="btn btn-primary" style="border-radius: 20px;"></a>
    </div>

    <div class="container">
        <main class="grid">
            <?php $__currentLoopData = $album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article>       
                <a href="/foto/<?php echo e($item->AlbumID); ?>">
                    <img src="img/3.jpg" width="265" height="265">
                    <div class="konten">
                        <p class="text-dark">Nama Album : <?php echo e($item->NamaAlbum); ?></p>
                        <p>Deskripsi :  <?php echo e($item->Deskripsi); ?></p>
                    </div>
                </a>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </main>
    </div>

    <!-- <script>
    document.addEventListener("DOMContentLoaded", function () {
        // mengambil semua elemen article
        var articles = document.querySelectorAll(".grid > article");

        articles.forEach(function (article, index) {
            article.addEventListener("click", function () {
                // ketika gambar di klik, larinya ke mana
                var url = "/foto";

                // ini buka tautan atau melakukan tindakannya
                window.location.href = url;
            });
        });
    });
    </script> -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH C:\Users\Lenovo\Web_Galeri_Foto\resources\views/album2.blade.php ENDPATH**/ ?>