<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Web Galeri Foto</title>
    <style>
        
     button {
            background-color: red; /* Warna tombol */
            color: #ffffff; /* Warna teks tombol */
            padding: 20px 15px;
            font-weight: bold;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        body {
            background-color: gray; /* b/ackground-color: white; Warna latar belakang */
            background: linear-gradient(to right, #ffcc00,#ff6600);
            font-weight: bold;
            font-family: Arial, sans-serif;
            color: #ffffff; /* Warna teks */
        }
        .jarak{
            margin-left:80%;
        }
        .image-list{
            margin-left:100px;
        }
        </style>
</head>
<body>
    <div class="nav">
    <center><h1>Welcome</h1></center>

    </div>
    <nav>
        <a href="album">Buat Album</a>
        <a href="tambahfoto">Tambah Foto</a>
        <a href="#services">Lihat Album</a>
    <header>
    </header>
    <style>

        nav a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        nav a:hover {
            background-color: #ddd;
            color: black;
        }
        </style>
    

    <div class="gallery">
    <div class="jarak">
        <center><a href="/home"><button type="submit">Home</button></a>
    <a href="/home"><button type="submit">Log Out </button></a></center>
    </div>
    <br>
        <div class="image-list">
            <a href=""><img src="img/rpl1.jpg" width="30%" alt="img/rpl1.jpg"></a>  
            <a href=""><img src="img/rpl1.jpg" width="30%" alt="img/rpl2.jpg"></a> 
            <a href=""><img src="img/rpl1.jpg" width="30%" alt="img/rpl1.jpg"></a> 
            <!-- Tambahkan gambar sesuai kebutuhan -->
        </div>

        <div class="upload-form">
            <h2>Unggah Gambar</h2>
            <form action="#" method="post" enctype="multipart/form-data">
                <label for="fileInput">Pilih Gambar:</label>
                <input type="file" id="fileInput" name="fileInput" accept="image/*">
        
               <center><center> <a href="tampilan"><button type="submit">Unggah</button></a> </center> </center>

            </form>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\Users\Lenovo\Web_Galeri_Foto\resources\views/Tampilan.blade.php ENDPATH**/ ?>