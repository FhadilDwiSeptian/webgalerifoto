-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 22, 2024 at 11:46 PM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `galeri_poto`
--

-- --------------------------------------------------------

--
-- Table structure for table `album`
--

CREATE TABLE `album` (
  `AlbumID` int NOT NULL,
  `NamaAlbum` varchar(255) NOT NULL,
  `Deskripsi` text NOT NULL,
  `TanggalDibuat` date NOT NULL,
  `UserID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `album`
--

INSERT INTO `album` (`AlbumID`, `NamaAlbum`, `Deskripsi`, `TanggalDibuat`, `UserID`) VALUES
(12, 'Makanan', 'Makanan', '2024-02-21', 26),
(13, 'Wisata', 'Wisata', '2024-02-21', 25),
(14, 'Peliharaan', 'Peliharaan', '2024-02-21', 27),
(15, 'Wisata', 'Wisata', '2024-02-21', 26),
(16, 'Sekolah', 'Sekolah', '2024-02-21', 26),
(17, 'Peliharaan', 'Hewan Peliharaan', '2024-02-21', 30);

-- --------------------------------------------------------

--
-- Table structure for table `komentarfoto`
--

CREATE TABLE `komentarfoto` (
  `KomentarID` int NOT NULL,
  `FotoID` int NOT NULL,
  `UserID` int NOT NULL,
  `IsiKomentar` text NOT NULL,
  `TanggalKomentar` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `komentarfoto`
--

INSERT INTO `komentarfoto` (`KomentarID`, `FotoID`, `UserID`, `IsiKomentar`, `TanggalKomentar`) VALUES
(8, 33, 27, 'man', '2024-02-21'),
(9, 32, 27, 'keren', '2024-02-21'),
(10, 32, 30, 'bagus', '2024-02-21');

-- --------------------------------------------------------

--
-- Table structure for table `likefoto`
--

CREATE TABLE `likefoto` (
  `LikeID` int NOT NULL,
  `FotoID` int NOT NULL,
  `UserID` int NOT NULL,
  `TanggalLike` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `likefoto`
--

INSERT INTO `likefoto` (`LikeID`, `FotoID`, `UserID`, `TanggalLike`) VALUES
(22, 33, 29, '2024-02-21'),
(23, 32, 29, '2024-02-21'),
(24, 31, 29, '2024-02-21'),
(25, 31, 30, '2024-02-21'),
(26, 32, 30, '2024-02-21'),
(27, 33, 30, '2024-02-21'),
(28, 34, 30, '2024-02-21');

-- --------------------------------------------------------

--
-- Table structure for table `poto`
--

CREATE TABLE `poto` (
  `FotoID` int NOT NULL,
  `JudulFoto` varchar(255) NOT NULL,
  `DeskripsiFoto` text NOT NULL,
  `TanggalUnggah` date NOT NULL,
  `LokasiFile` varchar(255) NOT NULL,
  `AlbumID` int NOT NULL,
  `UserID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `poto`
--

INSERT INTO `poto` (`FotoID`, `JudulFoto`, `DeskripsiFoto`, `TanggalUnggah`, `LokasiFile`, `AlbumID`, `UserID`) VALUES
(31, 'Pempek', 'Pempek Palembang', '2024-02-21', 'public/images/i2TIt6gtaDrNLFhi0dngGNz6az6hky9YiF1b26eU.jpg', 12, 26),
(32, 'Labuan Bajo', 'Labuan bajo NTT', '2024-02-21', 'public/images/3p6HZe5Kx9cUAl3BEEsxulTjwPCK5X8NaAilWTJx.jpg', 13, 25),
(33, 'Burung Lovebird', 'Lovebird', '2024-02-21', 'public/images/mM7v80vWw6Kgfrkc4jXyBkAK2HbNsh6Sbe0ZPk8R.jpg', 14, 27),
(34, 'pantai panjang', 'pantai panjang bengkulu', '2024-02-21', 'public/images/sHbzsI1pcJyFU59vhHE1smpHGnImTFkcvQK6jAOE.jpg', 17, 30);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserID` int NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `NamaLengkap` varchar(255) NOT NULL,
  `Alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `Username`, `Password`, `Email`, `NamaLengkap`, `Alamat`) VALUES
(18, 'y', 'y', 'fhadildi76@gmail.com', 'Fhadil Dwi Septian', 'duta'),
(25, 'yaya', 'y', 'yaya@gmail.com', 'yaya', 'bumi'),
(26, 'fhadil', 'y', 'fhadil@gmail.com', 'fhadil dwi septian', 'bumi'),
(27, 'tuyul', 'y', 'tuyul@gmail.com', 'tuyul', 'bumi'),
(28, 'tuyu', 'y', 'tuyu@gmail.com', 'tuyu', 'bumi'),
(29, 'zaki', 'y', 'zaki@gmail.com', 'zaki', 'talang jawa'),
(30, 'joko', '123', 'joko@gmail.com', 'joko putra', 'lingga');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `album`
--
ALTER TABLE `album`
  ADD PRIMARY KEY (`AlbumID`);

--
-- Indexes for table `komentarfoto`
--
ALTER TABLE `komentarfoto`
  ADD PRIMARY KEY (`KomentarID`);

--
-- Indexes for table `likefoto`
--
ALTER TABLE `likefoto`
  ADD PRIMARY KEY (`LikeID`);

--
-- Indexes for table `poto`
--
ALTER TABLE `poto`
  ADD PRIMARY KEY (`FotoID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `album`
--
ALTER TABLE `album`
  MODIFY `AlbumID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `komentarfoto`
--
ALTER TABLE `komentarfoto`
  MODIFY `KomentarID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `likefoto`
--
ALTER TABLE `likefoto`
  MODIFY `LikeID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `poto`
--
ALTER TABLE `poto`
  MODIFY `FotoID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UserID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
